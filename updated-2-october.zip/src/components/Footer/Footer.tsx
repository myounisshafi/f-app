import React from 'react'
import Typography from '@mui/material/Typography';
import style from './Footer.module.css';

function Footer() {
    return (
        <footer className="text-center text-lg-start bg-white text-muted">
            <section className="">
                <div className=" text-center text-md-start mt-5">
                    <div className="row mt-3">
                        <div className="col-md-3 col-lg-6 col-xl-3 mx-auto mb-4 text-md-center">
                            <Typography variant='h6' className={`text-uppercase fw-bold text-black ${style.footer_logo}`}>
                                <img src="logo.png" alt="" />
                            </Typography>
                            <div className={`${style.footer_icons} mt-3`}>
                                <ul className={` ${style.social__links} d-flex`}>
                                <li><a href="#!"><img src="facebook.svg" alt="" /></a></li>
                                <li><a href="#!"><img src="instagram.svg" alt="" /></a></li>
                                <li><a href="#!"><img src="tiktok.svg" alt="" /></a></li>
                            </ul>
                            </div>
                        </div>
                        <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                            <h6 className={`text-uppercase mb-4 fw-bold text-black ${style.footer_heading}`}>
                                Fluffie Tools
                            </h6>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Dupes</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Community</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Summariser</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Reviews</a>
                            </p>
                        </div>
                        <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                            <h6 className={`text-uppercase mb-4 fw-bold text-black ${style.footer_heading}`}>
                                About us
                            </h6>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">About</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Contact us</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">FAQ</a>
                            </p>
                        </div>
                        <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                            <h6 className={`text-uppercase mb-4 fw-bold text-black ${style.footer_heading}`}>
                                Policies
                            </h6>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Affiliate Disclosure</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Privacy Policy</a>
                            </p>
                            <p>
                                <a href="#!" className="text-reset text-decoration-none">Term of User</a>
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </footer>
    )
}

export default Footer