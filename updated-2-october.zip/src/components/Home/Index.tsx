import React from 'react'
import HeroSection from './HeroSection'
import SectionFive from './SectionFive'
import SectionFour from './SectionFour'
import SectionSix from './SectionSix'
import SectionThree from './SectionThree'
import SectionTwo from './SectionTwo'

function Home() {
    return (
        <>
            <HeroSection />
            <SectionTwo />
            <SectionThree />
            <SectionFour />
            <SectionFive />
            <SectionSix />
        </>
    )
}

export default Home