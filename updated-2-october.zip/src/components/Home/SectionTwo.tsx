import React from 'react'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import styles from "./home.module.css";

function SectionTwo() {
  
  return (
    <Box sx={{ flexGrow: 1 }} className={styles.section__two} id="section-two">
    <Grid container>
      <Grid xs={10} style={{ margin: "auto" }}>
        <Grid container>
          <Grid item xs={12} md={5} lg={6}>
            <img src="review-image.svg" alt="" />
          </Grid>
          <Grid item xs={12} md={7} lg={6} className={styles.right__side}>
            <Typography variant="h2" className='fw-bold ' >Real People <img src="verified.svg" className={`${styles.real_img}`} alt="" /></Typography>
            <Typography variant="h2" className='fw-bold' gutterBottom>Real <span className={styles.pink}>photo</span> reviews</Typography>
            <Typography variant="body2" gutterBottom className={styles.small__text}>
              contribute a photo, audio or video review, None of our reviews are #gifted or #promoted.
            </Typography>
            <Stack spacing={2} direction="row">
              <Button variant="contained" className={styles.review__button}>post a review</Button>
              <Button variant="text" className={styles.explore__review}>explore reviews</Button>
            </Stack>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  </Box>
  )
}

export default SectionTwo