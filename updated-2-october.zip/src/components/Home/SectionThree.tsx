import React from 'react'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import styles from "./home.module.css";

function SectionThree() {
    return (
        <Box sx={{ flexGrow: 1 }} className={styles.section__three}>
            <Grid container>
                <Grid xs={10} style={{ margin: "auto" }}>
                    <Typography variant="h3" gutterBottom className={`${styles.community}`}>
                                <strong>
                                    Our mission
                                </strong>
                            </Typography>
                    <Grid container>
                        <Grid item md={6} lg={6} xs={12}>
                            <Typography variant="h3" gutterBottom className={`${styles.community}`}>
                                Community + Transparency
                            </Typography>
                            <Typography variant="h3" className={`${styles.community} fw-bold`}>
                                = <span className={`${styles.pink} ${styles.community}`}>Less Fluff</span>
                            </Typography>
                        </Grid>
                        <Grid item md={6} lg={6} xs={12}>
                            <Typography variant="body2" gutterBottom>
                                We are sick of the product claim, promoted content, and all the marketing
                                noise out there. Our mission is to build an independent community of skincare
                                reviews to tackle the marketing stuff.
                            </Typography>
                            <Stack spacing={2} direction="row">
                                <Button variant="contained" className={styles.about__us}>About us</Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Box>
    )
}

export default SectionThree