import React from 'react'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import styles from "./home.module.css";
import Typography from '@mui/material/Typography';
import StarIcon from '@mui/icons-material/Star';



function SectionFour() {

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    arrows: false,
    appendDots: dots => <ul>{dots}</ul>,
    customPaging: i => (
      <div className="ft-slick__dots--custom">
        <div className="loading" />
      </div>
    )
  };
  console.log(Slider)

  return (
    <Box sx={{ flexGrow: 1 }} className={styles.section__four}>
      <Grid container>
        <Grid md={5} lg={4} xs={12} style={{ margin: "auto" }}>
          <Grid container>
            <Grid item xs={12}>
              <Typography variant='h3' className={`text-white fw-bold text-center ${styles.skin_care_summaries}`} gutterBottom>
                Skincare Summaries
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <div className={`${styles.active__slide} ${styles.slides}`}>
                    1
                  </div>
                </Grid>
                <Grid item xs={4} >
                  <div className={`${styles.active__slide} ${styles.slides}`}>
                    2
                  </div>
                </Grid>
                <Grid item xs={4} >
                  <div className={`${styles.active__slide} ${styles.slides}`}>
                    3
                  </div>
                </Grid>
              </Grid>
              <Typography variant='body1' className={`text-white text-center`} style={{ fontSize: '20px' }} gutterBottom>
                Quickly gain clarity by reading a summary of the main pros and cons of a product based on it's reviews
              </Typography>
              <Slider {...settings}>
                <div>
                  <div className={`container-fluid ${styles.card_wrapper}`}>
                    <div className={`${styles.img_text_sec}`}>
                      <div className="row">
                        <div className="col-md-4">
                          <img src="power.jpg" alt="" srcSet="" className={`${styles.img_power}`} />
                        </div>
                        <div className="col-md-8">
                          <h3>The Power Couple</h3>
                          <span className={`${styles.drunk}`}>Drunk Elephant</span>
                          <div className=' mt-3 pr-5'>
                             <StarIcon/> &nbsp; <span>4.5 &#x2022; 461 reviews</span>
                          </div>
                        </div>

                      </div>
                      <div className={`mt-4 ${styles.pros_card}`}>
                        <div className="d-flex align-items-center">
                          <h4>Pros  &nbsp;</h4><span><img src="line.png" alt="" srcSet="" /></span> 
                        </div>
                        <span className={`${styles.drunk}`}>Based on 461 positive reviews</span>
                        <ul className='mt-2'>
                          <li>Most reviews say the product <b>smooths, brightens, and helps with breakouts</b>.</li>
                          <li>Reviewers that have used the product for <b>months</b> mention <b>reduced wrinkles.</b></li>
                          <li> A smaller proportion of reviews say it <b>helped with pigmentation.</b></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <div className={`container-fluid ${styles.card_wrapper}`}>
                    <div className={`${styles.img_text_sec}`}>
                      <div className="row">
                        <div className="col-md-4">
                          <img src="product.png" alt="" srcSet="" className={`${styles.img_power}`} />
                        </div>
                        <div className="col-md-8">
                          <h3>A-Passioni™ Retinol Cream</h3>
                          <span className={`${styles.drunk}`}>Drunk Elephant</span>
                          <div className=' mt-3 pr-5'>
                            <StarIcon/> &nbsp; <span>4.5 &#x2022; 461 reviews</span>
                          </div>
                        </div>

                      </div>
                      <div className={`mt-4 ${styles.pros_card}`}>
                          <div className="d-flex align-items-center">
                          <h4>Summary  &nbsp;</h4><span><img src="line.png" alt="" srcSet="" /></span> 
                        </div>
                        <span className={`${styles.drunk}`}>Based on 461 positive reviews</span>
                        <ul className='mt-2'>
                          <li>Most reviews say the product <b>smooths, brightens, and helps with breakouts</b>.</li>
                          <li>Reviewers that have used the product for <b>months</b> mention <b>reduced wrinkles.</b></li>
                          <li> A smaller proportion of reviews say it <b>helped with pigmentation.</b></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div><div>
                  <div className={`container-fluid ${styles.card_wrapper}`}>
                    <div className={`${styles.img_text_sec}`}>
                      <div className="row">
                        <div className="col-md-4">
                          <img src="power.jpg" alt="" srcSet="" className={`${styles.img_power}`} />
                        </div>
                        <div className="col-md-8">
                          <h3>The Power Couple</h3>
                          <span className={`${styles.drunk}`}>Drunk Elephant</span>
                          <div className=' mt-3 pr-5'>
                             <StarIcon/> &nbsp; <span>4.5 &#x2022; 461 reviews</span>
                          </div>
                        </div>

                      </div>
                      <div className={`mt-4 ${styles.pros_card}`}>
                         <div className="d-flex align-items-center">
                          <h4>Pros  &nbsp;</h4><span><img src="line.png" alt="" srcSet="" /></span> 
                        </div>
                        <span className={`${styles.drunk}`}>Based on 461 positive reviews</span>
                        <ul className='mt-2'>
                          <li>Most reviews say the product <b>smooths, brightens, and helps with breakouts</b>.</li>
                          <li>Reviewers that have used the product for <b>months</b> mention <b>reduced wrinkles.</b></li>
                          <li> A smaller proportion of reviews say it <b>helped with pigmentation.</b></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </Slider>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  )
}

export default SectionFour