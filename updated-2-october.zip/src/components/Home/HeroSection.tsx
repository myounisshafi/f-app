import React from 'react'
import { ProgressBar } from 'react-bootstrap';
import styles from "./home.module.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import StarIcon from '@mui/icons-material/Star';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';


function HeroSection() {
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        arrows: false
    };
    return (
        
        <div className="container-fluid pb-5">
            <div className={styles.banner}>
                <div className="row d-flex">
                    <div className="col-md-6 ">
                        <div className={styles.banner__left__heading}>
                            <h1>Your place for<br></br> <span className="trans">transparent</span> <br></br>skincare reviews</h1>

                        </div>
                        <div className={styles.banner__left__paragraph}>
                            <p>We're building the largest community of authentic skincare reviews and summaries in the Southern Hemisphere.</p>

                        </div>
                        <form className={`d-flex ${styles.banner__joinUs}`}>
                            <button className={`btn ${styles.pink__btn}`} type="submit">
                                Join us
                            </button>
                            <div className={styles.Learn__more}> <a href="#section-two">Learn more</a></div>
                        </form>

                    </div>
                    <div className="col-md-6 align-items-center align-self-center">
                        <div className="banner-right-side">
                            <Slider {...settings}>
                                <div className="row d-flex" >
                                    <div className='col-md-6'>
                                        <img src="./product.png" alt="" srcSet="" className='img-fluid banner-iamge' />
                                    </div>
                                    <div className={`col-md-6 ${styles.product__info__sec}`}>
                                        <h1>
                                            A-Passioni™ Retinol Cream
                                        </h1>
                                        <span className={styles.drunk}>Drunk Elephant</span>
                                        <div className='rating-reviews mt-3 pr-5'>
                                            <StarIcon/> &nbsp; <span>4.5 &#x2022; 461 reviews</span>
                                        </div>
                                        <div className="progress-wrapper mt-3 ">
                                            <div className='d-flex justify-content-between'>
                                                <span>Smoother skin</span>
                                                <span>64 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={73} className={styles.progress__bar} />
                                        </div>
                                        <div className="progress-wrapper mt-3">
                                            <div className='d-flex justify-content-between'>
                                                <span>Brighter skin</span>
                                                <span>21 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={23} className={styles.progress__bar} />
                                        </div>
                                        <div className='mt-4'>
                                            <b>  Review summary</b>
                                        </div>
                                        <div className='mt-3'>
                                            Positive reviews mainly mention <b>smoother, brighter, softer, moisturised </b>and <b>clearer skin</b>.
                                        </div>
                                    </div>
                                </div>
                                <div className="row d-flex" >
                                    <div className='col-md-6'>
                                        <img src="./go.jpg" alt="" srcSet="" className='img-fluid banner-iamge' />
                                    </div>
                                    <div className={`col-md-6 ${styles.product__info__sec}`}>
                                        <h1>
                                            Go-To
                                        </h1>
                                        <span className={styles.drunk}>Face Hero</span>
                                        <div className='rating-reviews mt-3 pr-5'>
                                            <StarIcon/> &nbsp; <span>4.7 &#x2022; 2450 reviews</span>
                                        </div>
                                        <div className="progress-wrapper mt-3 ">
                                            <div className='d-flex justify-content-between'>
                                                <span>Hydrating</span>
                                                <span>759 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={73} className={styles.progress__bar} />
                                        </div>
                                        <div className="progress-wrapper mt-3">
                                            <div className='d-flex justify-content-between'>
                                                <span>Brighter skin</span>
                                                <span>528 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={23} className={styles.progress__bar} />
                                        </div>
                                        <div className='mt-4'>
                                            <b>  Review summary</b>
                                        </div>
                                        <div className='mt-3'>
                                            Positive reviews mainly mention hydrated and brighter skin, nice fragrance,
                                            that it's good for dry skin, and there's no oily finish or residue.
                                        </div>
                                    </div>
                                </div>
                                <div className="row d-flex" >
                                    <div className='col-md-6'>
                                        <img src="./glow.jpg" alt="" srcSet="" className='img-fluid banner-iamge' />
                                    </div>
                                    <div className={`col-md-6 ${styles.product__info__sec}`}>
                                        <h1>
                                            Watermelon Glow PHA+BHA Pore-Tight Toner
                                        </h1>
                                        <span className={styles.drunk}>Glow Recipe</span>
                                        <div className='rating-reviews mt-3 pr-5'>
                                            <StarIcon/> &nbsp; <span>4.6 &#x2022; 360 reviews</span>
                                        </div>
                                        <div className="progress-wrapper mt-3 ">
                                            <div className='d-flex justify-content-between'>
                                                <span>Nice scent & fragrance</span>
                                                <span>95 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={73} className={styles.progress__bar} />
                                        </div>
                                        <div className="progress-wrapper mt-3">
                                            <div className='d-flex justify-content-between'>
                                                <span>Hydrating</span>
                                                <span>58 &nbsp; <ChevronRightIcon/></span>
                                            </div>
                                            <ProgressBar now={23} className={styles.progress__bar} />
                                        </div>
                                        <div className='mt-4'>
                                            <b>  Review summary</b>
                                        </div>
                                        <div className='mt-3'>
                                            Positive reviewers like the scent of the product, say that it hydrates,
                                            brightens skin, refines pores, and smooths skin.
                                        </div>
                                    </div>
                                </div>
                            </Slider>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HeroSection