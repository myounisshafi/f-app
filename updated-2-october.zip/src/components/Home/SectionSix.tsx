import React from 'react'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import styles from "./home.module.css";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";


function SectionSix() {
  const settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    arrows: false
  };
  return (
    <Box sx={{ flexGrow: 1 }} className={styles.section__six}>
      <Slider {...settings}>
        <Grid container>
          <Grid md={9} lg={9} xs={12} style={{ margin: "auto" }}>
            <Grid container spacing={5}>
              <Grid item md={5} lg={5} xs={12}>
                <img src="reviews-panel.svg" alt="" />
              </Grid>
              <Grid item md={6} lg={6} xs={10} className={styles.claim__section}>
                <div className={styles.claim__text}>
                  <Typography variant='h2' gutterBottom className='fw-bold'>
                    Stop listening to claims!
                  </Typography>
                  <Typography variant='body1' gutterBottom>
                    Skincare retailers use product information to drive their
                    "filter by" toolbar - that means you're shown products based
                    solely on advertising claims.
                  </Typography>
                  <Stack spacing={2} direction="row">
                    <Button variant="contained" className={styles.review__button}>find a product</Button>
                  </Stack>
                </div>
              </Grid>
              <Grid item xs={1}>
                <ArrowForwardIosIcon className={styles.claim__arrow} />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container>
          <Grid md={9} lg={9} xs={12} style={{ margin: "auto" }}>
            <Grid container spacing={5}>
              <Grid item md={5} lg={5} xs={12}>
                <img src="reviews-panel.svg" alt="" />
              </Grid>
              <Grid item md={6} lg={6} xs={10} className={styles.claim__section}>
                <div className={styles.claim__text}>
                  <Typography variant='h2' gutterBottom className='fw-bold'>
                    Stop listening to claims!
                  </Typography>
                  <Typography variant='body1' gutterBottom>
                    Skincare retailers use product information to drive their
                    "filter by" toolbar - that means you're shown products based
                    solely on advertising claims.
                  </Typography>
                  <Stack spacing={2} direction="row">
                    <Button variant="contained" className={styles.review__button}>find a product</Button>
                  </Stack>
                </div>
              </Grid>
              <Grid item xs={1}>
                <ArrowForwardIosIcon className={styles.claim__arrow} />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container>
          <Grid md={9} lg={9} xs={12} style={{ margin: "auto" }}>
            <Grid container spacing={5}>
              <Grid item md={5} lg={5} xs={12}>
                <img src="reviews-panel.svg" alt="" />
              </Grid>
              <Grid item md={6} lg={6} xs={10} className={styles.claim__section}>
                <div className={styles.claim__text}>
                  <Typography variant='h2' gutterBottom className='fw-bold'>
                    Stop listening to claims!
                  </Typography>
                  <Typography variant='body1' gutterBottom>
                    Skincare retailers use product information to drive their
                    "filter by" toolbar - that means you're shown products based
                    solely on advertising claims.
                  </Typography>
                  <Stack spacing={2} direction="row">
                    <Button variant="contained" className={styles.review__button}>find a product</Button>
                  </Stack>
                </div>
              </Grid>
              <Grid item xs={1}>
                <ArrowForwardIosIcon className={styles.claim__arrow} />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Slider>
    </Box>
  )
}

export default SectionSix