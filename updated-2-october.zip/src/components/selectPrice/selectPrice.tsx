
import React from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import { Row, Col, } from 'react-bootstrap';
import styles from "./selectPrice.module.css";

function SelectPrice(props) {
   
  return (
  
           <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className={`${styles.modal_width_cstm_wrap}`}
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{borderBottom:'none'}}>
        {/* <Modal.Title id="contained-modal-title-vcenter">
          
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec , styles.modal_width_cstm} pt-2 pb-5`}>
               <h2 className="">Ray, let's find skincare products based on what other consumers say.</h2>
        <p className="mb-0 mt-3">
      What's your price range?
        </p>
        <div className="form_wrapper pt-3">
              {/* <Button variant="primary" className={`${styles.select_product_btn}`}>💵 $0-$50</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>💰 $50-$100</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>💸 $100+</Button> <br></br> */}
            <Form>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               💵 $0-$50
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               💰 $50-$100
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                💸 $100+
              </label>
              </div>
              </Form>
            <p className="mb-0 mt-3">
                What shade best matches your skin tone?
                    </p>
           
                <Row className="mt-3">
        <Col >
            <div className={`${styles.skin_color}`}></div>
        </Col>
        <Col ><div className={`${styles.skin_color1}`}></div></Col>
        <Col ><div className={`${styles.skin_color2}`}></div></Col>
        <Col ><div className={`${styles.skin_color3}`}></div></Col>
        <Col ><div className={`${styles.skin_color4}`}></div></Col>
        <Col ><div className={`${styles.skin_color5}`}></div></Col>
        <Col ><div className={`${styles.skin_color6}`}></div></Col>
        <Col ><div className={`${styles.skin_color7}`}></div></Col>
        <Col ><div className={`${styles.skin_color8}`}></div></Col>
        <Col ><div className={`${styles.skin_color9}`}></div></Col>

      </Row>
      <Row className={`${styles.skin_text}`}>
        <Col className="text-center">
        <p>Very fair</p>
        <span>burn easily can't tan</span>
        </Col>
          <Col className="text-center">
        <p>Fair</p>
        <span>usually burn sometimes tan</span>
        </Col>
          <Col className="text-center">
        <p>Medium</p>
        <span>sometimes burn usually tan</span>
        </Col>
          <Col className="text-center">
        <p>Olive</p>
        <span>rarely burn always tan</span>
        </Col>
          <Col className="text-center">
        <p>Brown</p>
        <span>never burn always tan</span>
        </Col>
          <Col className="text-center">
        <p>Dark</p>
        <span>never burn always tan</span>
        </Col>
      </Row>
      <div className='d-flex justify-content-end'>
        <Button variant="outline-secondary" onClick={() => props.nextModal("selectPrice")}>Next</Button>
      </div>
        </div>
        </div>
      </Modal.Body>
          </Modal>
          
  
  )
}

export default SelectPrice