import React from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styles from "./createPassword.module.css";

function CreatePassword(props) {
  return (
  
           <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      // className={`${styles.modal_width_cstm}`}
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{borderBottom:'none'}}>
        {/* <Modal.Title id="contained-modal-title-vcenter">
          
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec , styles.modal_width_cstm} pt-2 pb-5`}>
               <h2 className="text-center">Create a password</h2>
        <p className="text-center">
      Make sure it's 8 characters or more.
        </p>
        <div className="form_wrapper pt-3">
              <Form>

      <Form.Group className="mb-2" controlId="formBasicPassword">
        <Form.Label></Form.Label>
        <Form.Control className="pt-2 pb-2"  type="text" placeholder="" />
      </Form.Group>
            <div className="submit_btn">
              <Button variant="primary" className='w-100 mt-3 login_form_btn' style={{backgroundColor:"#fd7791" , border:"none", padding:"15px 0px"}} onClick={() => props.nextModal("createPassword")}>Continue</Button>
        </div>
    </Form>
        </div>
        </div>
      </Modal.Body>
          </Modal>
          
  
  )
}

export default CreatePassword