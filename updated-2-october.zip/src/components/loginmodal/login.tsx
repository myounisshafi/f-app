
import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styles from "./login.module.css";
import RegisterModal from '../register/register';


function Signup(props) {
 
  
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{borderBottom:'none'}}>
        {/* <Modal.Title id="contained-modal-title-vcenter">
          
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec} pt-2 pb-5`}>
               <h4 className="text-center">Welcome back!</h4>
        <p className="text-center">
        The Fluffie community is happy to see you again 🤗
        </p>
        <div className="form_wrapper pt-3">
              <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Phone Number</Form.Label>
        <Form.Control className="pt-2 pb-2" type="tel" placeholder="+ 62"  pattern="[]"/>
      </Form.Group>

      <Form.Group className="mb-2" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control className="pt-2 pb-2"  type="password" placeholder="Password" />
      </Form.Group>
            <a href="#">forget your passowrd?</a>
            <div className="submit_btn">
              <Button variant="primary" className='w-100 mt-3 login_form_btn' style={{backgroundColor:"#fd7791" , border:"none", padding:"15px 0px"}}>Login</Button>
                <div className="mt-2"><span>need a account?</span><a href="#" >Register</a></div>
        </div>
    </Form>
        </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default Signup;