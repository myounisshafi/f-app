import React from 'react'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import StarIcon from '@mui/icons-material/Star';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import styles from "./FindProducts.module.css";


function Product() {
    return (
        <Row className='me-3'>
            <Col xs={12} lg={3}>
                <Card className={`${styles.product_card}`}>
                    <Card.Img variant="top" src="product.png" className={`mx-auto ${styles.product_img} mb-3`} />
                    <Card.Body>
                        <Card.Title className={`${styles.product_card_title} mb-0`}>A-Passioni™ Retinol Cream</Card.Title>
                        <Card.Text className={`mb-2`}>Drunk Elephant</Card.Text>
                        <Card.Text className={`${styles.product_card_reviews}`}><StarIcon className={`${styles.product_card_reviews_star}`} />4.8 . 415 reviews</Card.Text>
                        <ul className={`${styles.product_card_product_features}`}>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                        </ul>
                        <Card.Text className={`${styles.product_card_product_price} text-center fw-bold`}>$88.00 - $105.00</Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs={12} lg={3}>
                <Card className={`${styles.product_card}`}>
                    <Card.Img variant="top" src="product.png" className={`mx-auto ${styles.product_img} mb-3`} />
                    <Card.Body>
                        <Card.Title className={`${styles.product_card_title} mb-0`}>A-Passioni™ Retinol Cream</Card.Title>
                        <Card.Text className={`mb-2`}>Drunk Elephant</Card.Text>
                        <Card.Text className={`${styles.product_card_reviews}`}><StarIcon className={`${styles.product_card_reviews_star}`} />4.8 . 415 reviews</Card.Text>
                        <ul className={`${styles.product_card_product_features}`}>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                        </ul>
                        <Card.Text className={`${styles.product_card_product_price} text-center fw-bold`}>$88.00 - $105.00</Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs={12} lg={3}>
                <Card className={`${styles.product_card}`}>
                    <Card.Img variant="top" src="product.png" className={`mx-auto ${styles.product_img} mb-3`} />
                    <Card.Body>
                        <Card.Title className={`${styles.product_card_title} mb-0`}>A-Passioni™ Retinol Cream</Card.Title>
                        <Card.Text className={`mb-2`}>Drunk Elephant</Card.Text>
                        <Card.Text className={`${styles.product_card_reviews}`}><StarIcon className={`${styles.product_card_reviews_star}`} />4.8 . 415 reviews</Card.Text>
                        <ul className={`${styles.product_card_product_features}`}>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                        </ul>
                        <Card.Text className={`${styles.product_card_product_price} text-center fw-bold`}>$88.00 - $105.00</Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col xs={12} lg={3}>
                <Card className={`${styles.product_card}`}>
                    <Card.Img variant="top" src="product.png" className={`mx-auto ${styles.product_img} mb-3`} />
                    <Card.Body>
                        <Card.Title className={`${styles.product_card_title} mb-0`}>A-Passioni™ Retinol Cream</Card.Title>
                        <Card.Text className={`mb-2`}>Drunk Elephant</Card.Text>
                        <Card.Text className={`${styles.product_card_reviews}`}><StarIcon className={`${styles.product_card_reviews_star}`} />4.8 . 415 reviews</Card.Text>
                        <ul className={`${styles.product_card_product_features}`}>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                            <li className={`mb-2`}><span>Good for dry skin</span><span className={`float-end fw-bold`}>55 <ArrowForwardIosIcon className={`${styles.product_card_feature_review_arrow}`} /></span></li>
                        </ul>
                        <Card.Text className={`${styles.product_card_product_price} text-center fw-bold`}>$88.00 - $105.00</Card.Text>
                    </Card.Body>
                </Card>
            </Col>
        </Row>
    )
}

export default Product