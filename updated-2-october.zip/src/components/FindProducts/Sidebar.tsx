import React from 'react'
import Accordion from 'react-bootstrap/Accordion';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Form from 'react-bootstrap/Form';
import Slider from '@mui/material/Slider';
import styles from "./FindProducts.module.css";
import { Typography } from '@mui/material';

function valuetext(value: number) {
    return `${value}°C`;
}

function Sidebar() {
    const [value, setValue] = React.useState<number[]>([20, 37]);

    const handleChange = (event: Event, newValue: number | number[]) => {
        setValue(newValue as number[]);
    };
    return (
        <Accordion defaultActiveKey={"0"} className={`${styles.side_bar}`}>
            <Typography variant='h5' className={`fw-bold px-5`}>
                Filter By
            </Typography>
            <Accordion.Item eventKey="0" className={`${styles.sidebar_accordian} px-5`}>
                <Accordion.Header className={`${styles.sidebar_accordian_header}`}>Skin Concerns</Accordion.Header>
                <Accordion.Body>
                    <Row>
                        <Col xs={12}>
                            <Typography variant='body1' className={`mt-2`} gutterBottom>Concern</Typography>
                            <DropdownButton id="dropdown-basic-button" className={`${styles.concern_dropdown}`} title="Dropdown button">
                                <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                            </DropdownButton>
                        </Col>
                        <Col xs={12}>
                            <Typography variant='body1' className={`mt-2`} gutterBottom>Skin benefits</Typography>
                            <DropdownButton id="dropdown-basic-button" className={`${styles.skin_benefit_dropdown}`} title="Dropdown button">
                                <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                            </DropdownButton>
                        </Col>
                    </Row>
                </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="0" className={`${styles.sidebar_accordian} px-5`}>
                <Accordion.Header className={`${styles.sidebar_accordian_header}`}>Skin Type</Accordion.Header>
                <Accordion.Body>
                    <Form>
                        <Form.Check
                            label="All"
                            className={`${styles.skin_type}`}
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Dry"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Oily"
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Normal"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Combination"
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Sensitive"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                    </Form>
                    <Typography variant='body1' className={`mb-2 mt-4`} gutterBottom>
                        Are you acne prone?
                    </Typography>
                    <DropdownButton id="dropdown-basic-button" title="Dropdown button" className={`${styles.concern_dropdown}`}>
                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                    </DropdownButton>
                </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="0" className={`${styles.sidebar_accordian} px-5`}>
                <Accordion.Header className={`${styles.sidebar_accordian_header}`}>Product Category</Accordion.Header>
                <Accordion.Body>
                    <Typography variant='body1'>
                        Main Category
                    </Typography>
                    <DropdownButton id="dropdown-basic-button" title="Dropdown button" className={`${styles.concern_dropdown} mb-3 mt-2`} >
                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                    </DropdownButton>
                    <Typography variant='body1'>
                        Subcategory
                    </Typography>
                    <DropdownButton id="dropdown-basic-button" title="Dropdown button" className={`${styles.concern_dropdown} mt-2`} >
                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                    </DropdownButton>
                </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="0" className={`${styles.sidebar_accordian} px-5`}>
                <Accordion.Header className={`${styles.sidebar_accordian_header}`}>Price</Accordion.Header>
                <Accordion.Body>
                    <Slider
                        className={`${styles.product_price_range}`}
                        getAriaLabel={() => 'Temperature range'}
                        value={value}
                        onChange={handleChange}
                        valueLabelDisplay="auto"
                        getAriaValueText={valuetext}
                    />
                    <Form className={`d-flex`}>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Control type="text" placeholder="" />
                        </Form.Group>

                        <div className={`${styles.divider}`}>

                        </div>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Control type="text" placeholder="" />
                        </Form.Group>
                    </Form>
                </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="0" className={`${styles.sidebar_accordian} px-5`}>
                <Accordion.Header className={`${styles.sidebar_accordian_header}`}>Source</Accordion.Header>
                <Accordion.Body>
                    <Form>
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="All"
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Mecca"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Sephore (in progress)"
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Adorebeauty (in progress)"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="hikoco (soon)"
                            name="group1"
                            type="radio"
                            id={`inline-radio-1`}
                        />
                        <Form.Check
                            className={`${styles.skin_type}`}
                            label="Paula's Choice (soon)"
                            name="group1"
                            type="radio"
                            id={`inline-radio-2`}
                        />
                    </Form>
                </Accordion.Body>
            </Accordion.Item>
        </Accordion>
    )
}

export default Sidebar