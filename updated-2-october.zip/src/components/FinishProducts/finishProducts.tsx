
import React from 'react'
import Link from 'next/link'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styles from "./finishProducts.module.css";


function FinishProducts(props) {

  return (

    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    // className={`${styles.modal_width_cstm}`}
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{ borderBottom: 'none' }}>
        {/* <Modal.Title id="contained-modal-title-vcenter">
          
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec, styles.modal_width_cstm} pt-2 pb-5`}>
          <h2 className="">Ray, let's find skincare products based on what other consumers say.</h2>
          <p className="mb-0 mt-3">
            Nearly there! Based on this simple 6 step routine,<br></br> Do you know what you want to do?
          </p>
          <div className="form_wrapper pt-3">
              <Form>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
              🧼 Cleanse
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🧽 Exfoliate
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🧴 Tone
              </label>
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                ⚗️ Treat
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               💧 Hydrate
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                 🌞 Protect
              </label>
            </div>
           </Form>
            {/* <Button variant="primary" className={`${styles.select_product_btn}`}>🧼 Cleanse</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🧽 Exfoliate</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🧴 Tone</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>⚗️ Treat</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>💧 Hydrate</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🌞 Protect</Button> */}
            <p className="mt-3">Or show me the supplementary stuff:</p>
                <Form>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
              🎭 Masks
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                👁️ Eye Care
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
              👄 Lip Care
              </label>
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
             🧣 Neck Care
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
            </div>
           </Form>
            {/* <Button variant="primary" className={`${styles.select_product_btn}`}>🎭 Masks</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>👁️ Eye Care</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>👄 Lip Care</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}> 🧣 Neck Care</Button> */}
            <a href="#" className={`${styles.looking_for}`}>I don't really know what I'm looking for 🤷</a>
            <div className='d-flex justify-content-end mt-5'>
              <Button variant="outline-secondary" ><Link href="/find-products">
              <span onClick={() => props.nextModal("finishModal")}>Finish</span>
              </Link></Button>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>


  )
}

export default FinishProducts