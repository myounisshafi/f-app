
import React, { useState } from 'react';
import Link from 'next/link'
import styles from "./header.module.css";
import Login from '../loginmodal/login';
import RegisterModal from '../register/register';
import CodeSent from '../CodeSent/codeSent';
import CreatePassword from '../CreatePassword/createPassword';
import SelectProducts from '../SelectProducts/selectProduct';
import SelectPrice from '../selectPrice/selectPrice';
import FinishProducts from '../FinishProducts/finishProducts';
import axios from 'axios'



function Header() {

  const [modalShow, setModalShow] = useState(false);
  const [registerModal, setRegisterModal] = useState(false);
  const [codeShow, setCodeShow] = useState(false);
  const [createShow, setCreatePassShow] = useState(false);
  const [selectShow, setSelectShow] = useState(false);
  const [selectPrice, setPriceShow] = useState(false);
  const [finishPrice, setFinishPrice] = useState(false);
  const [userRegisteration, setUserRegisteration] = useState({
    phonenumber: '',
    f_name: '',
    dob: '',
    skin_type: '',
    skin_concerns: '',
    price_range: '',
    skin_tone: '',
    purpose: '',
    suplementary_purpose: ''
  })

  const nextModal = (modalType) => {
    if (modalType == "register") {
      setRegisterModal(false);
      setCodeShow(true);
    } else if (modalType == "codeSent") {
      setCodeShow(false);
      setCreatePassShow(true);
    } else if (modalType == "createPassword") {
      setCreatePassShow(false);
      setSelectShow(true);
    } else if(modalType == "selectedProduct"){
      setSelectShow(false);
      setPriceShow(true);
    }else if(modalType == "selectPrice"){
      setPriceShow(false);
      setFinishPrice(true)
    }else if(modalType == "finishModal"){
      setFinishPrice(false)
    }
  }

  return (
    <nav className="navbar navbar-expand-lg pt-4">
      <div className={`container-fluid ${styles.container__inner}`}>
        <a className="navbar-brand" href="#">
          <Link href="/">
            <a className="nav-link"><img src="./logo.png" alt="" srcSet="" /></a>
          </Link>
        </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <form className={`d-flex ${styles.cstm__search}`}>
          <div className={`form-group ${styles.form__group}`}>
            <input className="form-control me-2 mt-2" type="search" placeholder="Search for 2000+ products... " aria-label="Search" />
            <img src="./search.png" alt="" srcSet="" className={`${styles.searchIcon}`} />
          </div>
        </form>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className={`navbar-nav m-auto mb-2 mb-lg-0 justify-content-center ${styles.cstm__navBar}`}>

            <li className="nav-item">
              <Link href="/find-products">
                <a className="nav-link">Find Products</a>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/about">
                <a className="nav-link">About</a>
              </Link>
            </li>
            <li className="nav-item">
              <a className="nav-link " aria-current="page" href="#">Explore</a>
            </li>
          </ul>
          <form className="d-flex">
            <div className={`${styles.singIn}`} onClick={() => setModalShow(true)}>Sign In</div>
            <button className={`btn ${styles.pink__btn}`} type="button" onClick={() => setRegisterModal(true)}>
              Get Started
            </button>
          </form>
        </div>
      </div>
      <Login
        show={modalShow}
        onHide={() => setModalShow(false)}
      ></Login>
      <RegisterModal
        show={registerModal}
        nextModal={nextModal}
        onHide={() => setRegisterModal(false)}></RegisterModal>

      <CodeSent
        show={codeShow}
        nextModal={nextModal}
        onHide={() => setCodeShow(false)}
      ></CodeSent>
      <CreatePassword
        nextModal={nextModal}
        show={createShow}
        onHide={() => setCreatePassShow(false)}
      >

      </CreatePassword>
      <SelectProducts
        show={selectShow}
        nextModal={nextModal}
        onHide={() => setSelectShow(false)}
      >

      </SelectProducts>
      <SelectPrice
        show={selectPrice}
        onHide={() => setPriceShow(false)}
        nextModal={nextModal}
      ></SelectPrice>

      <FinishProducts
        show={finishPrice}
        onHide={() => setFinishPrice(false)}
        nextModal={nextModal}
      >
      </FinishProducts>
    </nav>
  );
}

export default Header;
