import React, {useState} from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { DropdownDate, DropdownComponent } from "react-dropdown-date";
import styles from "./register.module.css";


const formatDate = (date) => {
  // formats a JS date to 'yyyy-mm-dd'
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-");
};

function RegisterModal(props) {


  const [inputValues, setInputValues] = useState({
    phone_number: '',
    f_name: '',
  })
  const [dateOfBirth, setDateOfBirth] = useState({
    date: null,
    selectedDate: "2012-11-15",
  })

  const inputHandler = (e) => {
    setInputValues({ ...inputValues, [e.target.name]: e.target.value })
    console.log(inputValues)
  }

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{ borderBottom: 'none' }}>
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec} pt-2 pb-5`}>
          <h4 className="text-center">Join our community and start browsing skincare products with more transparency.</h4>
          <p className="text-center">
            Your phone number can only be used to create one account.
          </p>
          <div className="form_wrapper pt-3">
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Phone Number</Form.Label>
                <Form.Control className="pt-2 pb-2" type="number" placeholder="+ 62" pattern="[]" name="phone_number" required onChange={(e) => inputHandler(e)} />
              </Form.Group>

              <Form.Group className="mb-2" controlId="formBasicPassword">
                <Form.Label>Full Name</Form.Label>
                <Form.Control className="pt-2 pb-2" type="text" placeholder="Full Name" name="f_name" required onChange={(e) => inputHandler(e)} />
              </Form.Group >
              <Form.Group className="mb-2">
                <Row className="pt-2">
                  <Col >
                    <Form.Label >Date of birth</Form.Label>
                    <div>
                      <DropdownDate selectedDate={dateOfBirth.selectedDate} onDateChange={(date) => setDateOfBirth({ date: date, selectedDate: formatDate(date) })} />
                    </div>
                  </Col>
                </Row>
              </Form.Group>
              <div className="submit_btn">
                <Button variant="primary" className='w-100 mt-4 login_form_btn' style={{ backgroundColor: "#fd7791", border: "none", padding: "15px 0px" }} onClick={() => props.nextModal("register")}>Continue</Button>
                <div className={`mt-3 text-center ${styles.register_info}`}><span>By continuing, you agree with our </span><a href="#">Terms of Service</a> <span>and</span> <a href="">Privacy Policy.</a>
                  <div className={`${styles.already_account}`}>
                    <a href="#">Already have an account?</a>
                  </div>
                </div>
              </div>
            </Form>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}
export default RegisterModal