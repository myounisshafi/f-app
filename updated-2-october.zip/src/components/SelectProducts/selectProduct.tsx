
import React from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styles from "./selectProduct.module.css";

function SelectProducts(props) {
  return (

    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    // className={`${styles.modal_width_cstm}`}
    >
      <Modal.Header closeButton className="cstm_modal_header" style={{ borderBottom: 'none' }}>
        {/* <Modal.Title id="contained-modal-title-vcenter">
          
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body  >
        <div className={`${styles.modal_body_sec, styles.modal_width_cstm} pt-2 pb-5`}>
          <h2 className="">Ray, let's find skincare products based on what other consumers say.</h2>
          <p className="mb-0 mt-3">
            Which of these options sounds like you?
          </p>
          <div className="form_wrapper pt-3">
            <Form>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🪔 Oily
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🌵 Dry
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                👌 Normal
              </label>
              </div>
                     <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                😰 Sensitive
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🤝 Combination
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                🤔 Not sure
              </label>
            </div>
           </Form>

            {/* <Button variant="primary" className={`${styles.select_product_btn}`}>🪔 Oily</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🌵 Dry</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>👌 Normal</Button> <br></br>
            <Button variant="primary" className={`${styles.select_product_btn}`}>😰 Sensitive</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🤝 Combination</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🤔 Not sure</Button> */}
            <p className="mt-3">What's your  <strong>number one</strong> concern right now?</p>
                <Form>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               🌵 Dryness
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               💀 Dullness
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
                👵 Fine lines & wrinkles
              </label>
              </div>
                 <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               😞 Acne & pimples
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
             ☀️ Sun damage & pigmentation
                </label>
              </div>
               <div className="d-flex ">
              <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
               🔴 Redness & irritation
                </label>
                  <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
             🐡 Puffiness
                </label>
                    <input className={`${styles.cstm_radio} form-check-input`} type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
              <label className={`${styles.cstm_label} form-check-label`} for={`flexRadioDefault1`}>
             ⚫ Dark Circle
                </label>
              </div>
            </Form>
            {/* <Button variant="primary" className={`${styles.select_product_btn}`}>🌵 Dryness</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>💀 Dullness</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>👵 Fine lines & wrinkles</Button> <br></br>
            <Button variant="primary" className={`${styles.select_product_btn}`}> 😞 Acne & pimples</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>☀️ Sun damage & pigmentation</Button> <br></br>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🔴 Redness & irritation</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>🐡 Puffiness</Button>
            <Button variant="primary" className={`${styles.select_product_btn}`}>⚫ Dark Circles</Button> <br></br> */}

            <div className='d-flex justify-content-end' onClick={() => props.nextModal("selectedProduct")}>
              <Button variant="outline-secondary" >Next</Button>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>


  )
}

export default SelectProducts