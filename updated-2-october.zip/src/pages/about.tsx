import React from 'react'

function about() {
  return (
    <h1>about</h1>
  )
}

export default about