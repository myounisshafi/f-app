import React from 'react'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Sidebar from '../components/FindProducts/Sidebar';
import Product from '../components/FindProducts/Product';

function FindProducts() {
  return (
    <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={2}>
                <Grid item xs={3}>
                    <Sidebar />
                </Grid>
                <Grid item xs={9}>
                  <Product />
                </Grid>
            </Grid>
        </Box>
  )
}

export default FindProducts